import random
import os
from colorama import Fore, Style, init

# Initialize colorama
init(autoreset=True)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def roll_dice():
    return random.randint(1, 6)

def move_piece(position, steps, player_index):
    if position == -1 and steps == 6:
        return 0  # Enter the board
    elif position >= 0:
        new_position = position + steps
        if new_position >= 36:  # Wrap around the board
            new_position -= 36
        if new_position in destination_zones[player_index]:
            return new_position  
        return new_position
    else:
        return position  # Piece can't move if not on the board

def check_winner(positions):
    return all(all(pos in destination_zones[i] for pos in player) for i, player in enumerate(positions))

def initialize_game(players_count):
    global positions, turn, colors, players_colors, board, destination_zones, color_map
    positions = [[-1, -1, -1, -1] for _ in range(players_count)]
    turn = 0
    colors = ["Red", "Green", "Blue", "Yellow"]
    color_map = {"Red": Fore.RED, "Green": Fore.GREEN, "Blue": Fore.BLUE, "Yellow": Fore.YELLOW}
    players_colors = []
    for i in range(players_count):
        print(f"Player {i+1}, choose your color:")
        for idx, color in enumerate(colors):
            print(f"{idx}. {color_map[color]}{color}")
        color_choice = int(input("Enter the number of your chosen color: "))
        players_colors.append(colors.pop(color_choice))
    board = [["."] * 9 for _ in range(4)]
    destination_zones = {0: [36, 37, 38, 39], 1: [40, 41, 42, 43], 2: [44, 45, 46, 47], 3: [48, 49, 50, 51]}

def update_board():
    global board
    board = [["."] * 9 for _ in range(4)]
    for i, player in enumerate(positions):
        for j, pos in enumerate(player):
            if 0 <= pos < 36:
                row, col = divmod(pos, 9)
                board[row][col] = color_map[players_colors[i]] + players_colors[i][0]  # First letter of color
            elif pos in destination_zones[i]:
                board[3][destination_zones[i].index(pos)] = color_map[players_colors[i]] + f"[{players_colors[i][0]}]"  # Destination marker

def display_board():
    update_board()
    print("Board:")
    for row in board:
        print(" ".join(row))
    for i in range(len(positions)):
        print(f"Player {i+1} ({color_map[players_colors[i]]}{players_colors[i]}): {positions[i]}")

def main_loop():
    global positions, turn

    while True:
        clear_screen()
        if check_winner(positions):
            print(f"Player {turn + 1} ({color_map[players_colors[turn]]}{players_colors[turn]}) wins!")
            break

        display_board()
        dice_roll = roll_dice()
        print(f"Player {turn + 1} ({color_map[players_colors[turn]]}{players_colors[turn]}) rolled a {dice_roll}.")

        extra_turn = dice_roll == 6

        if dice_roll == 6 or any(pos >= 0 for pos in positions[turn]):
            piece_to_move = -1
            while piece_to_move not in range(4) or (positions[turn][piece_to_move] == -1 and dice_roll != 6):
                try:
                    piece_to_move = int(input(f"Player {turn + 1} ({color_map[players_colors[turn]]}{players_colors[turn]}), which piece to move? (0-3): "))
                except ValueError:
                    continue
                if positions[turn][piece_to_move] == -1 and dice_roll != 6:
                    print("You need to roll a 6 to move this piece.")
                    piece_to_move = -1

            positions[turn][piece_to_move] = move_piece(positions[turn][piece_to_move], dice_roll, turn)
            print("Positions: ", positions)

        if not extra_turn:
            turn = (turn + 1) % len(positions)  # Switch between players

def main_menu():
    while True:
        clear_screen()
        print(Fore.CYAN + Style.BRIGHT + "Welcome to Mensch game!")
        print(Fore.GREEN + "1. New Game (2 or 4 Players)")
        print(Fore.YELLOW + "2. How to Play")
        print(Fore.RED + "3. Exit")
        choice = input(Fore.CYAN + Style.BRIGHT + "Enter your choice: ")
        if choice == "1":
            while True:
                player_count = input("Enter number of players (2 or 4): ")
                if player_count in ["2", "4"]:
                    initialize_game(int(player_count))  # Initialize with selected number of players
                    main_loop()
                    break
                else:
                    print(Fore.RED + "Invalid number of players. Please enter 2 or 4.")
        elif choice == "2":
            clear_screen()
            print(Fore.GREEN + Style.BRIGHT + "How to Play:")
            print("1. Roll the dice and move your piece accordingly.")
            print("2. You need a 6 to start moving a piece from your home.")
            print("3. You can't land on a position with your own piece.")
            print("4. First to get all pieces to the destination zone wins.")
            input("Press Enter to return to the main menu.")
        elif choice == "3":
            break
        

if __name__ == "__main__":
    main_menu()
